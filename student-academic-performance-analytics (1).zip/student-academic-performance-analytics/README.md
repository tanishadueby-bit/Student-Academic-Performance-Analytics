# Student Academic Performance Analytics

## Project Overview
I created this project to analyze student academic performance using marks, attendance, subjects and semester-wise performance.

The dataset contains 20 academic records covering 10 students across the 1st and 2nd semesters.

## Objectives
- Analyze student marks.
- Compare attendance and academic performance.
- Study subject-wise performance.
- Compare semester-wise results.
- Identify areas that may need improvement.
- Present results using Excel tables and charts.

## Tools Used
Microsoft Excel, IBM Bob and GitHub.

## Project Files
- `data/student_academic_performance.xlsx` - Main formatted Excel dataset and analytics.
- `data/student_academic_performance.csv` - CSV version.
- `analysis/academic_performance_analysis.xlsx` - Supporting analysis.
- `docs/project_report.md` - Project report.
- `docs/bob_prompt.txt` - IBM Bob prompt.
- `charts/` - Folder for exported charts.

## Key Findings
The sample contains 20 records for 10 students. Average attendance is about 88.80% and average marks are about 79.35%. The project compares first and second semester performance.
