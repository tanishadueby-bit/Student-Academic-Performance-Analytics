# Student Academic Performance Analytics - Project Report

## Introduction
I created this project to understand student academic performance by combining marks, attendance, subjects and semester-wise results.

## Dataset
I used 20 academic records for 10 students. The records cover the 1st and 2nd semesters and include marks, attendance, performance score, grade and performance level.

## Analysis
I compared marks across subjects and semesters and included attendance to study the relationship between attendance and academic performance.

## Findings
1. The dataset contains 20 records for 10 students.
2. Average marks are about 79.35%.
3. Average attendance is about 88.80%.
4. The 2nd semester shows stronger average performance in this sample.
5. Attendance and marks can be compared to identify students who may need academic support.

## Conclusion
This project shows how a small academic dataset can be used to understand marks, attendance, subject performance and semester-wise trends.

## Future Improvements
I can add more semesters, student-wise dashboards, attendance alerts, grade distribution and an interactive dashboard.
